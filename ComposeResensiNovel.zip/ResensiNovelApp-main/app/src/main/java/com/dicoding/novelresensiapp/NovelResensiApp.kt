package com.dicoding.novelresensiapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp


@HiltAndroidApp
class NovelResensiApp: Application()