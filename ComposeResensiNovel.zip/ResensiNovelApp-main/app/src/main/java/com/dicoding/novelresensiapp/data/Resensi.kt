package com.dicoding.novelresensiapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "resensi")
data class Resensi(
    @PrimaryKey(autoGenerate = true)
    val id: Int? =null,
    val judul: String,
    val penulis: String,
    val penerbit: String,
    val tahunterbit: Int,
    val sinopsis: String,
    val kelebihan: String,
    val kekurangan: String,
    val photo: Int,
    val rating: Double,
    val totalview: Int,
    var isFavorite: Boolean=false,
)