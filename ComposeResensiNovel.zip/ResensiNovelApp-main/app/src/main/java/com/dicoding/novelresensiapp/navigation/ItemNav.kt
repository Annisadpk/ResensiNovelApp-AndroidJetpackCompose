package com.dicoding.novelresensiapp.navigation

import androidx.compose.ui.graphics.vector.ImageVector
import com.dicoding.novelresensiapp.navigation.PanelNav

data class ItemNav(
    val title: String,
    val icon: ImageVector,
    val panel: PanelNav
)
