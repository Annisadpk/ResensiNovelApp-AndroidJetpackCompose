package com.dicoding.novelresensiapp.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.data.ResensiData
import com.dicoding.novelresensiapp.repository.ResensiRepository
import com.dicoding.novelresensiapp.ui.HomeUiState
import com.dicoding.novelresensiapp.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: ResensiRepository) : ViewModel() {
    private val _allResensi = MutableStateFlow<ResultState<List<Resensi>>>(ResultState.Loading)
    val allResensi = _allResensi.asStateFlow()

    private val _homeUiState = mutableStateOf(HomeUiState())
    val homeUiState: State<HomeUiState> = _homeUiState

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getAllResensi().collect { resensi ->
                when (resensi.isEmpty()) {
                    true -> repository.insertAllResensi(ResensiData.dummy)
                    else -> _allResensi.value = ResultState.Success(resensi)
                }
            }
        }
    }

    private fun searchResensi(query: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.searchResensi(query)
                .catch { _allResensi.value = ResultState.Error(it.message.toString()) }
                .collect { _allResensi.value = ResultState.Success(it) }
        }
    }

    fun updateFavoriteResensi(id: Int, isFavorite: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateFavoriteResensi(id, isFavorite)
        }
    }

    fun onQueryChange(query: String) {
        _homeUiState.value = _homeUiState.value.copy(query = query)
        searchResensi(query)
    }

}