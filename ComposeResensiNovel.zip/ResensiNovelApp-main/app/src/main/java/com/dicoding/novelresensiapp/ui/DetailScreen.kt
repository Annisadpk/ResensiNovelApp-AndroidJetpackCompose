package com.dicoding.novelresensiapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.MaterialTheme
import androidx.compose.material.ScaffoldState
import androidx.compose.material.SnackbarDuration
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.rememberScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.dicoding.novelresensiapp.R
import com.dicoding.novelresensiapp.component.ErrorView
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.utils.ResultState
import com.dicoding.novelresensiapp.utils.formatNumber
import com.dicoding.novelresensiapp.viewmodel.DetailViewModel
import kotlinx.coroutines.launch


@Composable
fun DetailScreen (resensiId: Int, navController: NavController, scaffoldState: ScaffoldState) {
    val detailViewModel = hiltViewModel<DetailViewModel>()
    detailViewModel.resensi.collectAsState(ResultState.Loading).value.let { resultState ->
        when (resultState) {
            is ResultState.Loading -> detailViewModel.getResensi(resensiId)
            is ResultState.Error -> ErrorView()
            is ResultState.Success -> {
                DetailContent(
                    resultState.data,
                    navController,
                    scaffoldState,
                    detailViewModel::updateFavoriteResensi
                )
            }
        }
    }
}

@Composable
fun DetailContent(
    resensi: Resensi,
    navController: NavController,
    scaffoldState: ScaffoldState,
    onUpdateFavoriteResensi: (id: Int, isFavorite: Boolean) -> Unit,
) {
    val coroutineScope = rememberCoroutineScope()
    val (id, judul, penulis, penerbit, tahunterbit, sinopsis, kelebihan, kekurangan, photo, _, totalview, isFavorite) = resensi

    Box(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(bottom = 16.dp)
        ) {
            Box {
                // Main image
                AsyncImage(
                    model = photo,
                    contentDescription = judul,
                    contentScale = ContentScale.Crop,
                    placeholder = painterResource(R.drawable.anabudanceofkatherines),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                )

                // Secondary image at the bottom center
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(8.dp)
                ) {
                    AsyncImage(
                        model = photo, // Use the same image as the main image, you can replace it with a different image if needed
                        contentDescription = judul,
                        placeholder = painterResource(R.drawable.anabudanceofkatherines),
                        modifier = Modifier
                            .size(230.dp)
                            .clip(RectangleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(modifier = Modifier.padding(start = 8.dp, end = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = judul,
                        style = MaterialTheme.typography.h5
                    )

                    Icon(
                        imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        tint = if (isFavorite) Color(0xFF625b71) else MaterialTheme.colors.onSurface,
                        contentDescription = judul,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(100))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                onUpdateFavoriteResensi(id ?: 0, !isFavorite)
                                coroutineScope.launch {
                                    scaffoldState.snackbarHostState.showSnackbar(
                                        message = "$judul ${if (isFavorite) "dihapus dari" else "ditambahkan ke"} daftar favorite ",
                                        actionLabel = "Abaikan",
                                        duration = SnackbarDuration.Short
                                    )
                                }
                            },
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Text(
                        text = "${formatNumber(totalview)} views",
                        style = MaterialTheme.typography.body2
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Novel berjudul $judul ini ditulis oleh $penulis dan diterbitkan pada Tahun $tahunterbit oleh $penerbit",
                    style = MaterialTheme.typography.body1.copy(textAlign = TextAlign.Justify),
                    lineHeight = 24.sp,
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Sinopsis",
                    style = MaterialTheme.typography.h6.copy(fontWeight = FontWeight.Bold),
                    lineHeight = 24.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = sinopsis,
                    style = MaterialTheme.typography.body1.copy(textAlign = TextAlign.Justify),
                    lineHeight = 24.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Kelebihan",
                    style = MaterialTheme.typography.h6.copy(fontWeight = FontWeight.Bold),
                    lineHeight = 24.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = kelebihan,
                    style = MaterialTheme.typography.body1.copy(textAlign = TextAlign.Justify),
                    lineHeight = 24.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Kekurangan",
                    style = MaterialTheme.typography.h6.copy(fontWeight = FontWeight.Bold),
                    lineHeight = 24.sp,
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = kekurangan,
                    style = MaterialTheme.typography.body1.copy(textAlign = TextAlign.Justify),
                    lineHeight = 24.sp,
                )

            }



        }

        IconButton(
            onClick = { navController.navigateUp() },
            modifier = Modifier
                .padding(start = 8.dp, top = 8.dp)
                .align(Alignment.TopStart)
                .clip(CircleShape)
                .size(40.dp)
                .testTag("back_button")
                .background(Color.White)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = null,
            )
        }
    }
}


@Composable
@Preview(showBackground = true)
fun DetailContentPreview() {
    val resensi = Resensi(
        id = 1,
        judul = "Novel",
        penulis = "This is an example tour description.",
        penerbit = "Tittle",
        tahunterbit = 2003,
        sinopsis = "Sinopsis",
        kelebihan = "Kelebihan",
        kekurangan = "Kekurangan",
        photo = R.drawable.anabudanceofkatherines,
        rating = 3.9,
        totalview = 100,
        isFavorite = false
    )

    DetailContent(
        resensi = resensi,
        navController = NavController(LocalContext.current),
        scaffoldState = rememberScaffoldState(),
        onUpdateFavoriteResensi = { _,_->}
        )
}

