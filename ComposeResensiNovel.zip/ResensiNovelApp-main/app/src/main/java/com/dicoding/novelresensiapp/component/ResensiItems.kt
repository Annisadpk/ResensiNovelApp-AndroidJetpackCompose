package com.dicoding.novelresensiapp.component

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.ScaffoldState
import androidx.compose.material.SnackbarDuration
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.rememberScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.dicoding.novelresensiapp.R
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.navigation.PanelNav
import com.dicoding.novelresensiapp.utils.countRate
import com.dicoding.novelresensiapp.utils.formatNumber
import kotlinx.coroutines.launch


@SuppressLint("SuspiciousIndentation")
@Composable
@Preview
fun HomePanelPreview() {
    val navController = rememberNavController()
    val scaffoldState = rememberScaffoldState()

    val dummyResensiList = listOf(
        Resensi(id = 1, judul = "Judul Novel", penerbit = "Penerbit", penulis = "Penulis", tahunterbit = 2020, sinopsis = "Sinopsis", kelebihan = "Kelebihan", kekurangan = "Kekurangan", photo = R.drawable.anabudanceofkatherines, rating = 4.5, totalview = 2345678, isFavorite = false),
        Resensi(id = 2, judul = "Judul Novel", penerbit = "Penerbit", penulis= "Penulis", tahunterbit = 2020, sinopsis = "Sinopsis", kelebihan = "Kelebihan", kekurangan = "Kekurangan", photo = R.drawable.aromakarsa, rating = 2.5, totalview = 6757890, isFavorite = true),
    )

    AvailableView(
        listResensi = dummyResensiList,
        navController = navController,
        scaffoldState = scaffoldState,
        onUpdateFavoriteResensi = { _, _ -> /* Handle favorite tour update */ }
    )
}


@Composable
fun AvailableView(
    listResensi: List<Resensi>,
    navController: NavController,
    scaffoldState: ScaffoldState,
    onUpdateFavoriteResensi: (id: Int, isFavorite: Boolean) -> Unit,
) {
    LazyColumn {
        items(listResensi, key = { it.judul }) { novel ->
            ResensiItems(novel , navController, scaffoldState, onUpdateFavoriteResensi)
        }
    }
}

@Composable
fun ResensiItems(
    novel: Resensi,
    navController: NavController,
    scaffoldState: ScaffoldState,
    onUpdateFavoriteResensi: (id: Int, isFavorite: Boolean) -> Unit,
) {
    val coroutineScope = rememberCoroutineScope()
    val (id, judul, penulis, penerbit, tahunterbit, _, _, _, photo, rating, totalview, isFavorite) = novel

    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.small)
            .border(1.dp, Color.LightGray.copy(0.5f), MaterialTheme.shapes.small),
    ) {
        Box(
            modifier = Modifier
                .clickable {
                    navController.navigate(PanelNav.Detail.createRoute(id ?: 0))
                }
        ) {
            Column {
                Box {

                    Image(
                        painter = rememberAsyncImagePainter(model = photo),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(MaterialTheme.shapes.small)
                            .background(MaterialTheme.colors.background)
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(bottomEnd = 8.dp))
                            .background(MaterialTheme.colors.primary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = penerbit,
                                style = MaterialTheme.typography.body2,
                                color = MaterialTheme.colors.onPrimary
                            )
                            Text(
                                text = "Terbit Tahun $tahunterbit ",
                                style = MaterialTheme.typography.body2,
                                color = MaterialTheme.colors.onPrimary
                            )
                        }

                    }
                }

                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(2.dp),
                    ) {

                        AsyncImage(
                            model = photo,
                            contentDescription = judul,
                            contentScale = ContentScale.FillWidth,
                            placeholder = painterResource(R.drawable.anabudanceofkatherines),
                            modifier = Modifier
                                .size(width = 100.dp, height = 140.dp)
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colors.background)
                                .padding(3.dp)
                        )
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                            ) {
                                Text(
                                    text = judul,
                                    style = MaterialTheme.typography.h6.copy(fontSize = 23.sp),
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = penulis,
                                    style = MaterialTheme.typography.body2
                                )

                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val nRate = countRate(rating)
                                repeat(nRate) {
                                    Icon(
                                        imageVector = Icons.Rounded.Favorite,
                                        contentDescription = judul,
                                        tint = Color(0xFFB6C100)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$rating/5 (${formatNumber(totalview)} views)",
                                    style = MaterialTheme.typography.body2
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = ("Lihat selengkapnya..."),
                                    style = MaterialTheme.typography.body2,
                                    modifier = Modifier
                                        .padding(8.dp)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Icon(
                                    imageVector = if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    tint = if (isFavorite) Color(0xFF625b71) else MaterialTheme.colors.onSurface,
                                    contentDescription = judul,
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(100))
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null
                                        ) {
                                            onUpdateFavoriteResensi(id ?: 0, !isFavorite)
                                            coroutineScope.launch {
                                                scaffoldState.snackbarHostState.showSnackbar(
                                                    message = "$judul ${if (isFavorite) "dihapus dari" else "ditambakan ke"} daftar favorite ",
                                                    actionLabel = "Abaikan",
                                                    duration = SnackbarDuration.Short
                                                )
                                            }
                                        },
                                )
                            }
                        }
                    }

                }
            }
        }
    }
}
