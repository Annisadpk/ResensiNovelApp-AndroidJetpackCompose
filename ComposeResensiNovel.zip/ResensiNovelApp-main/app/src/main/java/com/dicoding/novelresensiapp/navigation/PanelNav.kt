package com.dicoding.novelresensiapp.navigation


sealed class PanelNav(val route: String) {
    object Home : PanelNav("home")
    object Favorite : PanelNav("favorite")
    object Profile : PanelNav("profile")
    object Detail : PanelNav("detail/{resensiId}") {
        fun createRoute(resensiId: Int): String {
            return "detail/$resensiId"
        }
    }
}