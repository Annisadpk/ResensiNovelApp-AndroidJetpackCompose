package com.dicoding.novelresensiapp.repository

import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.data.ResensiDao
import javax.inject.Singleton
import javax.inject.Inject

@Singleton
class ResensiRepository  @Inject constructor(private val resensiDao: ResensiDao) {
    fun getAllResensi() = resensiDao.getAllResensi()
    fun getAllFavoriteResensi() = resensiDao.getAllFavoriteResensi()
    fun getResensi(id: Int) = resensiDao.getResensi(id)
    fun searchResensi(query: String) = resensiDao.searchResensi(query)
    suspend fun insertAllResensi(resensi: List<Resensi>) = resensiDao.insertAllResensi(resensi)
    suspend fun updateFavoriteResensi(id: Int, isFavorite: Boolean) = resensiDao.updateFavoriteResensi(id,isFavorite)
}