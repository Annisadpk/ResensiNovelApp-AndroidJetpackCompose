package com.dicoding.novelresensiapp.data

import com.dicoding.novelresensiapp.R

object ResensiData {
    val dummy = listOf(
        Resensi(
            judul = "An Abundance of Katherines",
            penulis = " John Green",
            penerbit ="Speak" ,
            tahunterbit = 2006,
            sinopsis="Novel ini menceritakan tentang seorang anak SMA bernama Colin yang selama hidupnya telah memacari sembilan belas perempuan yang aneh tapi nyata, semuanya bernama Katherine. Sayangnya, kesembilan belas mantannya tersebut mencampakkannya, hal tersebut membuatnya merasa begitu sakit hati dan depresi.\n" +
                    "\n" +
                    "Hassan, sahabat Collin, pun berinisiatif untuk mengajak Colin pergi selama beberapa hari, mengendarai mobil tanpa tujuan pasti. Hingga ketika mereka tiba di Gutshot, Tennessee. Colin dan Hassan memutuskan untuk tinggal karena hal menarik yang ditawarkan kepada mereka. Bersama perempuan bernama Lindsey yang mereka kenal di sana, Hassan dan Colin pun menjalani petualangan yang bisa dibilang cukup dadakan.\n" +
                    "\n" +
                    "Di sisi lain, Colin yang masih merasa sakit hati akan putusnya hubungannya dengan Katherine XIX, sedang berusaha untuk membuktikan The Theorem of Underlying Katherine Predictability, dimana ia harap dapat digunakan untuk memprediksi masa depan suatu hubungan.",
            kelebihan = "Gaya bahasa dari novel terjemahannya sudah cukup bagus. Bahasanya tidak terlalu baku, sehingga mudah dimengerti oleh pembaca.",
            kekurangan = "Novel ini melibatkan cukup banyak grafik kartesius dan juga rumus matematika yang membuat pusing pembacanya.",
            photo = R.drawable.anabudanceofkatherines,
            rating = 4.5,
            totalview = 3456738,
        ),
        Resensi(
            judul = "Anak Semua Bangsa",
            penulis = " Pramoedya Ananta Toer",
            penerbit ="Lentera Dipantara" ,
            tahunterbit = 1980,
            sinopsis="Novel ini berisi tentang lanjutan dari Bumi Manusia yang menceritakan tentang Annelis, istri dari Minke harus pergi ke Nederland tetapi tidak lama ia menetap disana, ia harus menghembuskan nafas terakhirnya.\n" +
                    "\n" +
                    "Dari situ Minke dan Nyai Ontosoroh (mamanya) harus tetap kuat dan tegar dalam menghadapi segala musibah yang silih berganti menimpa mereka. Minke yang merupakan lulusan dari H.B.S memiliki banyak kemampuan, salah satunya menulis dalam bahasa Belanda. Banyak orang yang telah membaca tulisan Minke, Jean Marais dan Kommer memberi ia masukan untuk menulis dalam bahasa Melayu dan lebih belajar memahami negaranya sendiri.\n" +
                    "\n" +
                    "Selain itu ada juga Khouw Ah Soe, seorang pejuang Cina yang menggalang persatuan di Surabaya juga ikut memberi banyak informasi mengenai perkembangan penjajahan dunia. Lewat pemikiran tersebut, akhirnya Minke sadar bahwa kedudukan Belanda dibangsannya mulai goyah. Jepang sebagai satu-satunya negara Asia yang posisinya setara dengan Eropa, telah siap mengambil alih wilayah Hindia.",
            kelebihan = "Cerita yang disampaikan dari awal sampai akhir cukup jelas\n" +
                    "Dapat memperkenalkan lebih dalam mengenai sejarah Indonesia pada masa kolonialisme Belanda",
            kekurangan = "Tokoh yang ada didalam novel terlalu banyak, sehingga terkadang tidak fokus dalam alur ceritanya",
            photo = R.drawable.anaksemuabangsa,
            rating = 4.8,
            totalview = 5689754,
        ),
        Resensi(
            judul = "Aroma Karsa",
            penulis = " Dee Lestari",
            penerbit ="Benteng Pustaka" ,
            tahunterbit = 2018,
            sinopsis="Dari sebuah lontar kuno, Raras Prayagung mengetahui bahwa Puspa Karsa yang dikenalnya sebagai dongeng, ternyata tanaman sungguhan yang tersembunyi di tempat rahasia.\n" +
                    "\n" +
                    "Obsesi Raras memburu Puspa Karsa, bunga sakti yang konon mampu mengendalikan kehendak dan cuma bisa diidentifikasi melalui aroma, mempertemukannya dengan Jati Wesi. Jati memiliki penciuman luar biasa. Di TPA Bantar Gebang, tempatnya tumbuh besar, ia dijuluki si Hidung Tikus. Dari berbagai pekerjaan yang dijalankannya untuk bertahan hidup, satu yang paling Jati banggakan, yakni meracik parfum.\n" +
                    "\n" +
                    "Kemampuan Jati memikat Raras. Bukan hanya mempekerjakan Jati di perusahaannya, Raras ikut mengundang Jati masuk ke dalam kehidupan pribadinya. Bertemulah Jati dengan Tanaya Suma, anak tunggal Raras, yang memiliki kemampuan serupa dengannya. Semakin jauh Jati terlibat dengan keluarga Prayagung dan Puspa Karsa, semakin banyak misteri yang ia  temukan, tentang dirinya dan masa lalu yang tak pernah ia tahu.",
            kelebihan = "Karakter-karakter yang ada didalam novel sangat menarik sehingga tidak berfokus pada karakter utama saja.",
            kekurangan = "Novel ini cukup tebal sehingga sulit dibawa kemana-mana.",
            photo = R.drawable.aromakarsa,
            rating = 4.7,
            totalview = 5689754,
        ),
        Resensi(
            judul = "Bumi Manusia",
            penulis = " Pramoedya Ananta Toer",
            penerbit ="Lentera Dipantara" ,
            tahunterbit = 2018,
            sinopsis="Bumi Manusia bercerita tentang Minke, seorang pribumi yang bersekolah di HBS. Padahal pada masa itu, yang dapat masuk ke sekolah HBS adalah orang-orang keturunan Eropa.\n" +
                    "\n" +
                    "Ia merasa gelisah melihat nasib pribumi lainnya yang tertindas. Melihat kondisi di sekitarnya itu, Minke tergerak untuk memperjuangkan nasib pribumi melalui tulisan, yang menurutnya membuat suaranya tidak akan padam ditelan angin.\n" +
                    "\n" +
                    "Di tengah cerita, Bumi Manusia juga memiliki sinopsis kisah cinta antara Minke dan Annelies, gadis Indo yang juga anak dari Nyai Ontosoroh dengan tuannya Herman Mellema. Novel ini juga menggambarkan kondisi masa kolonialisme belanda pada saat itu.",
            kelebihan = "Alur ceritanya sangat menarik dan permasalahan ditulis cukup jelas\n" +
                    "Banyak memberi beberapa gambaran yang sangat jelas mengenai masalah-masalah yang timbul dalam kehidupan manusia di jaman kolonialisme",
            kekurangan = "Ada beberapa bahasa yang digunakan terlalu puitis, sehingga sulit untuk dimengerti.",
            photo = R.drawable.bumimanusia,
            rating = 4.9,
            totalview = 6609254,
        ),
        Resensi(
            judul = "Daun Yang Jatuh Tak Pernah Membenci Angin",
            penulis = " Tere Liye",
            penerbit ="PT Gramedia Pustaka Utama" ,
            tahunterbit = 2010,
            sinopsis="Buku karangan Tere Liye ini mengisahkan tentang kehidupan seorang anak perempuan dari keluarga kurang mampu yang merasakan rasanya jatuh cinta dengan orang yang umurnya berbeda jauh dengannya.\n" +
                    "\n" +
                    "Anak perempuan tersebut bernama Tania. Ia tinggal bersama dengan Ibu dan Adiknya di sebuah gubuk kardus. Ibunya bekerja sebagai buruh cuci dan untuk membiayai keluarga, Tania dan adiknya pun harus mengorbankan pendidikan mereka dan mengamen di jalan.\n" +
                    "\n" +
                    "Namun kehidupan mereka berubah ketika bertemu dengan Danar. Om Danar bersedia memberikan modal bagi Ibu dari Tania untuk membuat usaha kue kecil-kecilan. Melalui uluran tangan Om Danar pun Tania dan adiknya mampu melanjutkan pendidikannya.\n" +
                    "\n" +
                    "Tidak lama, Ibu dari Tania mengalami sakit keras dan pada akhirnya harus meninggal. Singkat cerita Tania tumbuh menjadi gadis remaja yang cantik, cerdas dan mandiri. Tania juga memendam perasaan kepada Om Danar. Namun, Om Danar malah menikah dengan Tante Ratna.\n" +
                    "\n" +
                    "Hingga pada suatu hari, Tante Ratna menghubungi Tania dan menyebut bahwa ada sosok yang tidak hilang dihati Om Danar. Setelah mendengar hal tersebut, Tania akhirnya berani menyatakan perasaannya kepada Om Danar. Namun Om Danar hanya terdiam dan cerita pun berakhir dengan ending yang menggantung.",
            kelebihan = "Penulis mampu membawa para pembaca untuk mengerti cerita secara keseluruhan tanpa adanya kendala yang berarti",
            kekurangan = "Terdapat beberapa kesalahan ketik (typo)\n" +
                    "Ending cerita yang menggantung.",
            photo = R.drawable.daunyangjatuhtakpernahmembenciangin,
            rating = 4.3,
            totalview = 3452794,
        ),
        Resensi(
            judul = "Dibawah Lindungan Ka’bah",
            penulis = " Hamka",
            penerbit ="PT. Bulan Bintang" ,
            tahunterbit = 2001,
            sinopsis="Hamid adalah seorang anak yatim dan miskin. Dia kemudian diangkat oleh keluarga Haji Jafar yang kaya-raya. Hamid dianggap sebagai anak mereka sendiri, Mereka sangat menyayanginya sebab Hamid sangat rajin, sopan, berbudi, serta taat beragama.\n" +
                    "\n" +
                    "Hamid sangat menyayangi Zainab. Begitu pula dengan Zainab. Ketika keduanya beranjak remaja, dalam hati masing-masing mulai tumbuh perasaan lain. Suatu perasaan yang selama ini belum pernah mereka rasakan. Hamid merasakan bahwa rasa kasih sayang yang muncul terhadap Zainab melebihi rasa sayang kepada adik, seperti yang selama ini dia rasakan.\n" +
                    "\n" +
                    "Hamid tidak berani mengutarakan isi hatinya kepada Zainab sebab dia menyadari bahwa di antara mereka terdapat jurang pemisah yang sangat dalam. Zainab merupakan anak orang terkaya dan terpandang, sedangkan dia hanyalah berasal dari keluarga biasa dan miskin.\n" +
                    "\n" +
                    "Dalam waktu bersamaan, Hamid mengalami peristiwa yang sangat menyayat hatinya. Mulai dari meninggalnya Haji Jafar dan ibu Asiah ingin menjodohkan Zainab dengan pemuda lain.\n" +
                    "\n" +
                    "Bahkan, Mak Asiah meminta Hamid untuk membujuk Zainab agar mau menerima pemuda pilihannya. Hamid terpaksa menurutinya. Setelah itu Hamid memutuskan untuk pergi meninggalkan kampungnya.\n" +
                    "\n" +
                    "Ketika Hamid pergi ke tanah suci Mekah. Dia bertemu Saleh, teman sekampungnya. Dia mendapat banyak berita tentang kampungnya termasuk keadaan Zainab. Dari penuturan Saleh, Hamid mengetahui bahwa Zainab juga mencintainya. Sejak kepergian Hamid, Zainab sering sakit-sakitan. dia tidak jadi menikah dengan pemuda pilihan mamaknya. Namun pada akhirnya Zainab wafat akibat penyakitnya.",
            kelebihan = "Terdapat  banyak pelajaran hidup yang baik dijadikan sebagai pedoman.\n" +
                    "Kisahnya bersifat realigi sehingga sangat baik dibaca oleh para pemuda muslim.",
            kekurangan = "Sampul novel kurang menarik",
            photo = R.drawable.dibawahlindungankakbah,
            rating = 3.9,
            totalview = 3452794,
        ),
        Resensi(
            judul = "Dilan: Dia Adalah Dilanku Tahun 1990",
            penulis = " Pidi Baiq",
            penerbit ="PT. Miza Pustaka" ,
            tahunterbit = 2015,
            sinopsis="Novel dilan menceritakan tentang kisah cinta Milea. Milea adalah seorang murid baru pindahan dari Jakarta.\n" +
                    "\n" +
                    "Suatu hari, saat Dilan mengikuti Milea pulang dengan angkot ia berkata, “Milea, kamu cantik, tapi aku belum mencintaimu. Enggak tahu kalau sore. Tunggu aja”. Perkataan Dilan itu membuat hati Milea berdebar-debar, mungkin ia kaget atas ucapan Dilan. Milea diam mendengar ucapan itu, ia juga memikirkan Beni, pacarnya yang ada di Jakarta.\n" +
                    "\n" +
                    "Dilan mendekati Milea dengan cara yang tidak biasa, mungkin itu yang membuat Milea selalu memikirkannya. Lambat laun, seiring berjalannya waktu Milea dan Dilan menjadi akrab. Milea mengetahui beberapa hal tentang dilan dari Wati, sepupu Dilan yang sekelas dengannya.",
            kelebihan = "Novel ini mengajarkan bagaimana cara kita menjaga pasangan, agar hubungan bertahan lama dan komunikasi lancar\n" +
                    "Cover depan yang menarik Novel Dengan gambar seorang remaja SMA berdiri di depan motor.",
            kekurangan = "Ada beberapa kalimat yang terdengar aneh seperti banyak percakapan yang tidak nyambung, mungkin ini disebabkan karena pengaruh latar waktu tahun 1990.",
            photo = R.drawable.dilan,
            rating = 4.3,
            totalview = 3452794,
        ),
        Resensi(
            judul = "Laskar Pelangi",
            penulis = " Andrea Hirata",
            penerbit ="Bentang" ,
            tahunterbit = 2007,
            sinopsis="Ini adalah kisah tentang 11 anak Belitong yang tergabung dalam “Laskar Pelangi” mereka adalah Syahdan, Lintang, Kucai, Samson, A Kiong, Sahara, Trapani, Harun, Mahar, Flo dan sang tokoh utama Ikal. Cerita ini menceritakan kehidupan di pedalaman Belitong yang kaya akan timah namun rakyatnya tidak mampu memenuhi kebutuhan hidup sehari-hari.\n" +
                    "\n" +
                    "Novel ini bercerita tentang semangat juang dari anak-anak kampung Belitong untuk mengubah nasib mereka melalui sekolah. Sebagian besar orang tua mereka lebih senang melihat anak-anaknya bekerja membantu orang tua dari pada belajar disekolah.\n" +
                    "\n" +
                    "Suramnya pendidikan di desa itu tergambar jelas ketika SD Muhammadiyah terancam tutup jika murid baru sekolah itu tidak mencapai 10 orang , namun kesebelas anak itulah yang telah menyelamatkan masa depan pendidikan didesa itu yang hampir redup karena faktor ekonomi rakyatnya.\n" +
                    "\n" +
                    "Anak-anak Laskar Pelangi itu hidup dalam kebahagiaan masa kecil dan menyimpan mimpi masing-masing untuk masa mendatang , namun dua belas tahun kemudian, Ikal menyaksikan perubahan nasib teman-temannya yang sungguh diluar dugaan.\n" +
                    "\n" +
                    "Anak-anak Laskar Pelangi itu punya cita-cita setinggi langit, namun nasib jugalah yang menentukan kehidupan mereka selanjutnya. Mereka harus tunduk oleh nasib yang semestinya bisa diupayakan oleh pemerintah yang punya amanah dan kuasa untuk memajukan pendidikan.",
            kelebihan = "Memiliki arti perjuangan hidup dalam kemiskinan yang meruntuhkan cita – cita namun penuh pengharapan dan rasa persahabatan yang sangat kental.",
            kekurangan = "AAda kata-kata yang sulit untuk dipahami atau dapat kita mengerti , menggunakan kata-kata daerah yang belum diketahui artinya.",
            photo = R.drawable.laskarpelangi,
            rating = 4.9,
            totalview = 7452794,
        ),
        Resensi(
            judul = "Negeri 5 menara",
            penulis = " A.Fuadi",
            penerbit ="PT Gramedia Pustaka Utama" ,
            tahunterbit = 2009,
            sinopsis="Dikisahkan sebuah cerita dari tanah Minangkabau, yaitu Alif. Sejak kecil Alif memiliki cita-cita untuk menjadi seseorang seperti B.J. Habibie, tetapi ibunya menginginkan Alif menjadi seseorang seperti Buya Hamka. Hal itulah yang menjadi penghalang bagi tercapainya cita-cita Alif.\n" +
                    "\n" +
                    "Saat itu Alif diberikan dua pilihan untuk melanjutkan sekolahnya, yaitu sekolah di bidang keagamaan atau mondok di pesantren. Pilihan itu membuat Alif sangat marah, karena dia tidak bisa menggapai cita-citanya. Akhirnya, Alif memilih untuk mondok di sebuah pesantren di Jawa Timur, yaitu pondok Madani. Mendengar keputusan Alif, ibunya merasa berat hati karena Alif tidak memilih sekolah ataupun pondok yang berada di Minang. Kekhawatiran ibunya disebabkan oleh Alif yang tidak pernah keluar dari tanah Minang.\n" +
                    "\n" +
                    "\n" +
                    "Di pondok Madani, Alif merasa berat hati, karena dalam hati kecilnya dia ingin melanjutkan kuliah di ITB. Namun, ada satu hal yang membuat Alif berubah pandangan, sebuah kalimat yang diucapkan oleh pimpinan pondok, yakni Kiai Rais yang mengucapkan “Man Jadda Wa Jadda” barangsiapa bersungguh-sungguh pasti akan berhasil.\n" +
                    "\n" +
                    "Hal yang paling berat ketika di Pondok Madani adalah Alif dan kelima temannya harus belajar selama 24 jam dan hanya tidur beberapa menit saja, hal itu dilakukan untuk mempersiapkan mental mereka menghadapi ujian lisan dan tertulis. Disela sibuknya belajar Alif dan kelima temannya menyempatkan diri berkumpul di bawah menara masjid untuk membicarakan seputar cita-cita mereka sambil melihat awan untuk berimajinasi.\n" +
                    "\n" +
                    "Atas usaha dan perjuangan mereka, kini cita-cita yang sebelumnya hanyalah sebuah mimpi  menjadi kenyataan. Alif berada di Amerika, Baso di Asia, Atang di Afrika, Raja di Eropa, Said dan Dulmajid berada di Indonesia. Alif dan kelima temannya berada di bawah menara yang berbeda.",
            kelebihan = "Novel ini memberikan motivasi  untuk selalu semangat, berusaha, optimis, dan yakin dengan apa yang mereka cita-citakan.",
            kekurangan = "Penggunaan alurnya yang campuran, sehingga ceritanya sedikit rumit untuk dipahami.",
            photo = R.drawable.negerilimamenara,
            rating = 4.2,
            totalview = 2452794,
        ),
        Resensi(
            judul = "Pulang",
            penulis = " Tere Liye",
            penerbit ="Republika Penerbit" ,
            tahunterbit = 2015,
            sinopsis="Novel ini menceritakan seorang bocah bernama BUJANG (AGAM) yang tumbuh menjadi seorang Pria yang Gagah, Cerdas, Karismatik, Disegani dan penuh Emosional yang tak luput dari segala konflik dalam perjalanan panjang hidupnya. Novel ini membawa kita ke dalam dunia Permusuhan , Pertengkaran, Kesetiaan, Kekeluargaan dan Kehidupan yang sebenarnya.\n" +
                    "\n" +
                    "Novel ini akan mengajari kita pentingnya mengubah nasib dari bukan siapa-siapa menjadi manusia yang pantas untuk disegani meskipun hanya di dunia gelap. Dari Manusia yang bahkan membaca pun masih kesulitan hingga akhirnya menjadi manusia dengan lulusan terbaik di Universitas Amerika.\n" +
                    "\n" +
                    "Hal yang paling disukai di Novel ini adalah Bagaimana Si BUJANG mampu menjaga Amanat sang Ibu di dalam kerasnya perjalanan kehidupannya. Ternyata sehebat apapun diri Bujang, Dia tetap seorang anak yang sangat menjaga Pesan dan menghormati Petuah sang Ibu yang tak ditemuinya sampai dalam akhir hayat.",
            kelebihan = "Bahasa dan alur cerita yang mudah dipahami.",
            kekurangan = "Cover dalam Novel PULANG  kurang menarik , karena ketika kita membayangkan kata \"Pulang\" akan terlintas dalam benak pikiran adalah alam Pedesaan yang sejuk dan  menyamankan tapi cover novel ini terlihat di design sedikit menyeramkan dan kurang cerah meskipun warna hijau menjadi warna utama cover novel tersebut.",
            photo = R.drawable.pulang,
            rating = 4.2,
            totalview = 2123794,
        ),
        Resensi(
            judul = "Sang Pemimpi",
            penulis = " Andrea Hirata",
            penerbit ="Bentang Pustaka" ,
            tahunterbit = 2006,
            sinopsis="Novel berjudul Sang Pemimpi karya Andrea Hirata ini merupakan sekuel kedua dari tetralogi Laskar Pelangi. Novel ini mengisahkan tentang tiga orang pemuda yang berjuang meraih mimpi-mimpi dalam hidup mereka. Ketiga pemuda tersebut adalah Ikal, Arai, and Jimbron.\n" +
                    "\n" +
                    "Novel ini sesungguhnya menceritakan kisah hidup Ikal (tokoh utama dalam novel Laskar Pelangi) sewaktu remaja yang duduk di bangku SMA. Akan tetapi dalam novel ini secara khusus penulisnya menentukan tokoh-tokoh sentral yang berbeda dari novel sebelumnya yang tokoh-tokohnya adalah 10 anak Laskar Pelangi.",
            kelebihan = "Penggunaan gaya bahasa kepenulisan yang khas seperti halnya pada novel sebelumnya yakni Laskar Pelangi\n" +
                    "\n" +
                    "Menyajikan tentang pesan moral yang sangat kuat yakni beranilah bermimpi dan berjuang untuk meraihnya",
            kekurangan = "Konflik cerita yang tidak terlalu tajam",
            photo = R.drawable.sangpemimpi,
            rating = 4.2,
            totalview = 2123794,
        ),
        Resensi(
            judul = "Surat Kecil Untuk Tuhan",
            penulis = " Agnes Davonar",
            penerbit ="Inandra Published" ,
            tahunterbit = 2008,
            sinopsis="Novel ini mengisahkan tentang perjuangan seorang gadis untuk melawan kanker ganas. Gadis tersebut bernama Gita Sessa Wanda Cantika yang akrab disapa Keke. Ia divonis terkena kanker ganas dan hidupnya tinggal 5 hari.\n" +
                    "\n" +
                    "Kanker tersebut menyerang bagian wajah Keke sehingga Ia tampak seperti monster. Namun, Keke tetap berjuang untuk hidup dan mendapatkan pendidikan layaknya gadis lain seumurannya. Penyakit itu tidak diberitahukan kepada Keke karena mereka tidak tega melihat anaknya kehilangan separuh wajahnya apabila dilakukan operasi. Namun, pada akhirnya Keke pun mengetahui penyakitnya.\n" +
                    "\n" +
                    "Keke selalu tersenyum dan berjuang untuk hidup normal dan berprestasi seperti orang normal lainnya. Ayahnya pun terus berjuang demi kesembuhan Keke. Ayahnya berupaya mencari pengobatan alternatif di seluruh wilayah Indonesia, namun tidak membuahkan hasil. Akhirnya, menggunakan cara medis dan dokter menyarankan untuk kemoterapi.\n" +
                    "\n" +
                    "Keke mendapatkan keajaiban dari Tuhan sehingga Ia bisa menghabiskan waktu lebih lama dengan teman dan keluarga. Kanker tersebut merupakan penyakit pertama di Indonesia dan saat itu menjadi viral. Hal ini menimbulkan perdebatan di antara para dokter. Namun, setelah 3 tahun kanker itu kembali tumbuh di bagian tubuh lainnya.\n" +
                    "\n" +
                    "Ayahnya memutuskan untuk berobat ke Singapura. Dokter di sana pun menyarankan untuk melakukan operasi. Namun, akhirnya mereka kembali ke Indonesia dan keadaan Keke justru semakin parah. Hal ini dikarenakan kanker tersebut telah menyebar ke bagian organ tubuh lainnya, yaitu paru-paru dan jantung.\n" +
                    "\n" +
                    "Meski pun tangan dan kakinya sudah tidak bisa digerakkan, namun Keke tetap semangat belajar. Kondisi Keke semakin parah hingga mengalami koma dan dirawat di Rumah Sakit Cipto Mangunkusumo. Ditengah kondisinya tersebut ada kabar gembira, Keke mendapatkan prestasi sebagai juara tiga di ujian akhir di kelasnya,\n" +
                    "\n" +
                    "Akhirnya dokter menyerah dan Keke menghembuskan nafas terakhirnya pada 25 Desember 2006. Tepatnya, setelah puasa dan saat merayakan Idul Fitri. Sebelum meninggal, Keke sempat menuliskan surat kecil untuk Tuhan.",
            kelebihan = "Cerita di dalam novel ini diangkat dari kisah nyata sehingga sangat menyentuh hati pembaca. Penulis mampu membawa pembawa berimajinasi.",
            kekurangan = "Dijumpai beberapa kata kiasa sehingga sulit dimengerti oleh pembaca.",
            photo = R.drawable.suratkeciluntuktuhan,
            rating = 3.9,
            totalview = 2123794,
        ),
        Resensi(
            judul = "Tenggelamnya Kapal Van Der Wjick",
            penulis = " Hamka",
            penerbit ="Bulan Bintang" ,
            tahunterbit = 2012,
            sinopsis="Cerita dimulai dari seorang pemuda bernama Zainudin, ayahnya seorang minangkabau yang diasingkan karena membunuh ibunya yang selalu menggerogoti hartanya. Dia diasingkan di Cilacap lalu dipindahkan ke Makassar.\n" +
                    "\n" +
                    "Dalam novel ini memiliki kisah asmara Zainuddin jatuh hati sama Hayati. Hayati membalas cinta Zainuddin. Namun pada akhirnya Hayati tidak menikah dengan Zainuddin, melainkan dengan Aziz.\n" +
                    "\n" +
                    "Namun, hubungan mereka tidak harmonis. Sifat Aziz yang suka judi dan mabuk-mabukan diketahui oleh Hayati, Hayati semakin menderita saat Aziz bangkrut dan tak punya apa-apa. Karena frustasi dan depresi, Aziz bunuh diri.\n" +
                    "\n" +
                    "Dia meninggalkan pesan agar Hayati menikah dengan Zainudin. Namun, Zainuddin mengaku kalau sudah tak punya perasaan apa-apa kepada Hayati, padahal sebenarnya masih sayang.\n" +
                    "\n" +
                    "Akhirnya Hayati pergi ke Sumatra menggunakan kapal. Pada malam hari saat Hayati sedang tidur, Kapal Van Der Wijk yang dinaikinya tenggelam di dekat Lamongan. Besoknya Zainudin mendengar berita tersebut dan segera menuju Lamongan. Saat itu Hayati sedang kritis. Zainudin mengungkapkan perasaan sebenarnya kepada Hayati.\n" +
                    "\n" +
                    "Hayati tersenyum dan mengatakan bahwa ia juga masih mencintai Zainudin. Setelah mengatakan itu, Hayati menutup mata untuk selamanya.",
            kelebihan = "Novel ini sangat menyentuh hati pembacanya karena mengajarkan banyak hal salah satunya adalah untuk selalu sabar.",
            kekurangan = "Novel ini terlalu banyak menuliskan tentang surat Hayati dan Zainuddin sehingga membuat pembaca sedikit bosan untuk membaca tulisan tersebut.Novel ini terlalu banyak menuliskan tentang surat Hayati dan Zainuddin sehingga membuat pembaca sedikit bosan untuk membaca tulisan tersebut.",
            photo = R.drawable.tenggelamnyakapalvanderwijck,
            rating = 3.7,
            totalview = 2125632,
            ),

    )
}