package com.dicoding.novelresensiapp.ui


data class HomeUiState (
    val query: String = ""
)