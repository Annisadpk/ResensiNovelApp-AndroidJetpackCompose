package com.dicoding.novelresensiapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.repository.ResensiRepository
import com.dicoding.novelresensiapp.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavoriteViewModel @Inject constructor(private val repository: ResensiRepository) : ViewModel() {
    private val _allFavoriteResensi = MutableStateFlow<ResultState<List<Resensi>>>(ResultState.Loading)
    val allFavoriteResensi = _allFavoriteResensi.asStateFlow()

    init {
        fetchAllFavoriteResensi()
    }

    private fun fetchAllFavoriteResensi() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getAllFavoriteResensi()
                .catch { handleError(it) }
                .collect { handleSuccess(it) }
        }
    }

    private fun handleError(throwable: Throwable) {
        _allFavoriteResensi.value = ResultState.Error(throwable.message.toString())
    }

    private fun handleSuccess(resensiList: List<Resensi>) {
        _allFavoriteResensi.value = ResultState.Success(resensiList)
    }

    fun updateFavoriteResensi(id: Int, isFavorite: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateFavoriteResensi(id, isFavorite)
        }
    }
}

