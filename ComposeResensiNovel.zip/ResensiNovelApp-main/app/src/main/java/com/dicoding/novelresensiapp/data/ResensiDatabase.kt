package com.dicoding.novelresensiapp.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Resensi::class], version = 1, exportSchema = false)
abstract class ResensiDatabase : RoomDatabase() {
    abstract fun ResensiDao():ResensiDao
}