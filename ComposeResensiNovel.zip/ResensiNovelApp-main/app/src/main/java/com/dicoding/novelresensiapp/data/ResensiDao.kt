package com.dicoding.novelresensiapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ResensiDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllResensi(resensiList: List<Resensi>)

    @Query("SELECT * FROM resensi WHERE id = :id")
    fun getResensi(id: Int): Flow<Resensi>

    @Query("SELECT * FROM resensi")
    fun getAllResensi(): Flow<List<Resensi>>

    @Query("SELECT * FROM resensi WHERE Judul LIKE '%' || :query || '%'")
    fun searchResensi(query: String): Flow<List<Resensi>>

    @Query("SELECT * FROM resensi WHERE isFavorite = 1")
    fun getAllFavoriteResensi(): Flow<List<Resensi>>

    @Query("UPDATE resensi SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteResensi(id: Int, isFavorite: Boolean)

}