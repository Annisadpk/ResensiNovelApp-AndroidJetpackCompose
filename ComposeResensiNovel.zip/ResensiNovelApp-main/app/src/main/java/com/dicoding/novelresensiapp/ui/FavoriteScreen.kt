package com.dicoding.novelresensiapp.ui

import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.ScaffoldState
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.dicoding.novelresensiapp.component.AvailableView
import com.dicoding.novelresensiapp.component.EmptyView
import com.dicoding.novelresensiapp.component.ErrorView
import com.dicoding.novelresensiapp.component.ProgressBar
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.utils.ResultState
import com.dicoding.novelresensiapp.viewmodel.FavoriteViewModel

@Composable
fun FavoriteScreen(navController: NavController, scaffoldState: ScaffoldState) {
    val viewModelFavorite = hiltViewModel<FavoriteViewModel>()

    // Collect the state using collectAsState
    val resultState = viewModelFavorite.allFavoriteResensi.collectAsState(ResultState.Loading).value

    Scaffold(
        topBar = {
            // Add the TopAppBar with navigation icon, title, and actions
            TopAppBar(
                title = { Text("Favorite Resensi") },
                elevation = 4.dp,
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = MaterialTheme.colors.onPrimary
            )
        },
        content = {
            // Use when statement to handle different ResultStates
            when (resultState) {
                is ResultState.Loading -> ProgressBar()
                is ResultState.Error -> ErrorView()
                is ResultState.Success -> {
                    FavoriteContent(
                        listFavoriteResensi = resultState.data,
                        navController = navController,
                        scaffoldState = scaffoldState,
                        onUpdateFavoriteTour = viewModelFavorite::updateFavoriteResensi
                    )
                }
            }
        }
    )
}

@Composable
fun FavoriteContent(
    listFavoriteResensi: List<Resensi>,
    navController: NavController,
    scaffoldState: ScaffoldState,
    onUpdateFavoriteTour: (id: Int, isFavorite: Boolean) -> Unit
) {
    when (listFavoriteResensi.isEmpty()) {
        true -> EmptyView()
        false -> AvailableView(listFavoriteResensi, navController, scaffoldState, onUpdateFavoriteTour)
    }
}
