package com.dicoding.novelresensiapp.repository

import com.dicoding.novelresensiapp.data.ResensiDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped

@Module
@InstallIn(ViewModelComponent::class)
object ComponentRepository {
    @Provides
    @ViewModelScoped
    fun provideRepository(resensiDao: ResensiDao) = ResensiRepository(resensiDao)
}