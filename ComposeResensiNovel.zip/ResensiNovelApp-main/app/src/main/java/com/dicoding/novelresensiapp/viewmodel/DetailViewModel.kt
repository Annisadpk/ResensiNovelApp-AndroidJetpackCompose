package com.dicoding.novelresensiapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.repository.ResensiRepository
import com.dicoding.novelresensiapp.utils.ResultState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(private val resensiRepository: ResensiRepository) : ViewModel() {
    private val _resensi = MutableStateFlow<ResultState<Resensi>>(ResultState.Loading)
    val resensi = _resensi.asStateFlow()

    fun getResensi(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            resensiRepository.getResensi(id)
                .catch { _resensi.value = ResultState.Error(it.message.toString()) }
                .collect { _resensi.value = ResultState.Success(it) }
        }
    }

    fun updateFavoriteResensi(id: Int, isFavorite: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            resensiRepository.updateFavoriteResensi(id, isFavorite)
            }
        }
}