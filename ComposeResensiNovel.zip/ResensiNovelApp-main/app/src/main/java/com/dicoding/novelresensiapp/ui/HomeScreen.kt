package com.dicoding.novelresensiapp.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.ScaffoldState
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.dicoding.novelresensiapp.component.AvailableView
import com.dicoding.novelresensiapp.component.EmptyView
import com.dicoding.novelresensiapp.component.ErrorView
import com.dicoding.novelresensiapp.component.ProgressBar
import com.dicoding.novelresensiapp.component.SearchBar
import com.dicoding.novelresensiapp.data.Resensi
import com.dicoding.novelresensiapp.utils.ResultState
import com.dicoding.novelresensiapp.viewmodel.HomeViewModel

@Composable
fun HomeScreen(navController: NavController, scaffoldState: ScaffoldState) {
    val viewModelHome = hiltViewModel<HomeViewModel>()
    val homeUiState by viewModelHome.homeUiState
    TopAppBar(
        title = { Text("Novel Resensi App") },
        elevation = 4.dp,
        backgroundColor = MaterialTheme.colors.primary,
        contentColor = MaterialTheme.colors.onPrimary
    )
    viewModelHome.allResensi.collectAsState(ResultState.Loading).value.let { resultState ->
        when (resultState) {
            is ResultState.Loading -> ProgressBar()
            is ResultState.Error -> ErrorView()
            is ResultState.Success -> {
                HomeContent(
                    listResensi = resultState.data,
                    navController = navController,
                    scaffoldState = scaffoldState,
                    query = homeUiState.query,
                    onQueryChange = { query -> viewModelHome.onQueryChange(query) },
                    onUpdateFavoriteResensi = viewModelHome::updateFavoriteResensi
                )
            }
        }
    }
}

@Composable
fun HomeContent(
    listResensi: List<Resensi>,
    navController: NavController,
    scaffoldState: ScaffoldState,
    query: String,
    onQueryChange: (String) -> Unit,
    onUpdateFavoriteResensi: (id: Int, isFavorite: Boolean) -> Unit
) {
    Column {
        SearchBar(query = query, onQueryChange = onQueryChange, modifier = Modifier.padding(top = 56.dp))
        when (listResensi.isEmpty()) {
            true -> EmptyView()
            false -> AvailableView(listResensi, navController, scaffoldState, onUpdateFavoriteResensi)
        }
    }
}




